---
title: "HALOS: Heliostat Aimpoint and Location Optimization Software"
excerpt: "A tool for optimizing central receiver system plant.<br/><img src='/images/halos.png'>"
collection: portfolio
---

Details to be posted after public release of the tool.
