---
title: "Internal Combustion Engines"
collection: teaching
type: "Lecture"
permalink: /teaching/2022-spring-ic-engine
venue: "BUITEMS, Department of Mechanical Engineering"
date: 2022-04-18
location: "Quetta, Pakistan"
---

MECH-421 - 2 Credit Hours - Spring 2022

<!---
Internal Combustion Engines
======
-->

Welcome to IC Engine class! 
The course material and lectures will be posted on this site and students will be notified accordingly. 

Downloads
======
[Course Outline/Syllabus](https://github.com/kashifliaqat/kashifliaqat.github.io/raw/master/files/ic_syllabus.pdf)



[Mid Formula Sheet](https://github.com/kashifliaqat/kashifliaqat.github.io/raw/master/files/ic_engine_2021/Mid_Formula_Sheet.pdf)

<!--
    
[Grades](https://github.com/kashifliaqat/kashifliaqat.github.io/raw/master/files/ic_engine_2021/grades_ic_engine.pdf)



[Presentation groups](https://github.com/kashifliaqat/kashifliaqat.github.io/raw/master/files/ic_engine_2021/Presentation_groups.pdf) - 
[Presentation topics](https://github.com/kashifliaqat/kashifliaqat.github.io/raw/master/files/ic_engine_2021/IC_Engine_Presentation_Topics.pdf)

[Quiz 1 - MATLAB Code](https://github.com/kashifliaqat/kashifliaqat.github.io/raw/master/files/ic_engine_2021/Quiz_1_MATLAB_Code.pdf)
-->

Lectures
======
Reference Book: "Engineering Fundamentals of the Internal Combustion Engine" by Willard W. Pulkrabek, Second Edition

| **Date**   | **Lecture No. (Download Link)**                                                                                      | **Topic**                            |
|------------|----------------------------------------------------------------------------------------------------------------------|--------------------------------------|
| 20/04/2022 | [Lecture 1](https://github.com/kashifliaqat/kashifliaqat.github.io/raw/master/files/IC_Engine_1.pdf)                 | Introduction                         |
| 27/04/2022 | See Lecture 1                | Introduction Continued                        |
| 04/05/2022 | No Class - Eid Vacations  | --           |
| 11/05/2022 | [Lecture 2](https://github.com/kashifliaqat/kashifliaqat.github.io/raw/master/files/ic_engine_2021/IC_Engine_2.pdf)  | Operating Characteristics            |
| 18/05/2022 | [Lecture 3](https://github.com/kashifliaqat/kashifliaqat.github.io/raw/master/files/ic_engine_2021/IC_Engine_3.pdf)  | Operating Characteristics + Problems |
| 25/05/2022 | See Lecture 3  | Problems|
| 01/06/2022 | Mechanical Workshop | Disassembly/Assembly of IC Engine |
| 08/06/2022 | [Lecture 4](https://github.com/kashifliaqat/kashifliaqat.github.io/raw/master/files/ic_engine_2021/IC_Engine_4.pdf)  | Engine Cycles 
| 15/06/2022 | [Lecture 5](https://github.com/kashifliaqat/kashifliaqat.github.io/raw/master/files/ic_engine_2021/IC_Engine_5.pdf)  | Problems (Engine Cycles)             |
| 22/06/2022 | Review                                                                                                           |  Mid Exam Review             |
| 29/06/2022 | No Class                                                                                                             | Mid Exams                            |
| 06/07/2022 | [Lecture 6](https://github.com/kashifliaqat/kashifliaqat.github.io/raw/master/files/ic_engine_2021/IC_Engine_6.pdf)  | Engine Fuels and Knocking            |
| 13/07/2022 | No Class                                                                                                             | Eid Holiday                       |
| 20/07/2022 | [Lecture 8](https://github.com/kashifliaqat/kashifliaqat.github.io/raw/master/files/ic_engine_2021/IC_Engine_8.pdf)  | Air and Fuel Induction               |
| 27/07/2022 | [Lecture 9](https://github.com/kashifliaqat/kashifliaqat.github.io/raw/master/files/ic_engine_2021/IC_Engine_9.pdf)  | Air and Fuel Induction (Problems)    |
| 03/08/2022 | See Lecture 9  | Air and Fuel Induction (Problems)    |

<!--

| 20/09/2021 | Lecture 10                                                                                                           | Student Presentations                |
| 27/09/2021 | [Lecture 11](https://github.com/kashifliaqat/kashifliaqat.github.io/raw/master/files/ic_engine_2021/IC_Engine_10.pdf)| Fluid Motion - Exhaust Flow          |
| 04/10/2021 | [Lecture 12](https://github.com/kashifliaqat/kashifliaqat.github.io/raw/master/files/ic_engine_2021/IC_Engine_12.pdf)| Heat Transfer in Engines             |
| 11/10/2021 & 18/10/2021 | [Lecture 13](https://github.com/kashifliaqat/kashifliaqat.github.io/raw/master/files/ic_engine_2021/IC_Engine_13.pdf)| Engine Emissions and Pollution       |

-->

Assignments/Homeworks
======


[Homework 1](https://github.com/kashifliaqat/kashifliaqat.github.io/raw/master/files/ic_engine_2022/Homework_1_IC_Engine.pdf) - Due at class time (22/06/2022)


[Homework 2 (Complex Engineering Problem #1)](https://github.com/kashifliaqat/kashifliaqat.github.io/raw/master/files/ic_engine_2021/Homework_2_IC_Engine_CEP.pdf) - Due at class time (24/08/2022)

<!--

[Homework 3](https://github.com/kashifliaqat/kashifliaqat.github.io/raw/master/files/ic_engine_2021/Homework_2_IC_Engine.pdf) - Due at class time (11/10/2021)

-->
